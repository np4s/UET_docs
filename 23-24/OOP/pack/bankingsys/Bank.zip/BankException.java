public class BankException extends Exception {

    /**
     * ok.
     */
    public BankException(String message) {
        super(message);
    }
}
